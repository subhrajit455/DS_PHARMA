export default {
  plugins: {
    autoprefixer: {},
  },
}
